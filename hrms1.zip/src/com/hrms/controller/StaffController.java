package com.hrms.controller;

import com.hrms.model.Login;
import com.jfinal.core.Controller;

public class StaffController extends Controller {
	public void index(){
		
	Login sd =	(Login) getSession().getAttribute("login");
		System.out.println("jinrudao "+sd.getPassword());
		render("index.html");
	}
	
	
	public void list(){
	
		render("/admin/staff_list.html");
	}
	

}
